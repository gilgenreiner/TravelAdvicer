package bll;

public class Error404 extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Error404(String message) {
		super(message);
	}
}
