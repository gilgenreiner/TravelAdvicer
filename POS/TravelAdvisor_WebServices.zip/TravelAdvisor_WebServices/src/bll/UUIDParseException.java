package bll;

public class UUIDParseException extends Exception{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UUIDParseException(String message) {
		super(message);
	}
}
