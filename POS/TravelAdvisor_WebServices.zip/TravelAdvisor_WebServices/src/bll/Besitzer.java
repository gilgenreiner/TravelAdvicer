package bll;

import java.util.UUID;

public class Besitzer extends Benutzer{
	
	public Besitzer() {
		super();
	}

	public Besitzer(String id) {
		super(id);
	}

	
}
