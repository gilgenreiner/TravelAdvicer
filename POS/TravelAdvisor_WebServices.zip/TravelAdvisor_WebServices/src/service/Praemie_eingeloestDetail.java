package service;

public class Praemie_eingeloestDetail {

}
